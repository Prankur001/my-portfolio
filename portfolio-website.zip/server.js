require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin1234';
const SESSION_SECRET = process.env.SESSION_SECRET || 'portfolio-session-secret';

// SMTP Configuration
const SMTP_HOST = process.env.SMTP_HOST;
const SMTP_PORT = process.env.SMTP_PORT || 587;
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const EMAIL_TO = process.env.EMAIL_TO || 'prankursagar@ece.du.ac.in';

let mailTransporter = null;
if (SMTP_HOST && SMTP_USER && SMTP_PASS) {
  mailTransporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: parseInt(SMTP_PORT, 10),
    secure: parseInt(SMTP_PORT, 10) === 465,
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS
    }
  });
  console.log('Nodemailer SMTP Transporter initialized.');
} else {
  console.log('Nodemailer SMTP details missing in .env. Running in EMAIL SIMULATION mode.');
}

// Helper function to send email notification
async function sendEmailNotification(name, email, subject, message) {
  const mailOptions = {
    from: SMTP_USER ? `"Portfolio Hub" <${SMTP_USER}>` : '"Portfolio Hub" <noreply@portfolio.com>',
    to: EMAIL_TO,
    replyTo: email,
    subject: `New Portfolio Inquiry: ${subject}`,
    text: `You have received a new message from your portfolio contact form:\n\nName: ${name}\nEmail: ${email}\nSubject: ${subject}\n\nMessage:\n${message}`,
    html: `
      <div style="font-family: Arial, sans-serif; padding: 20px; color: #333; max-width: 600px; border: 1px solid #ddd; border-radius: 8px;">
        <h2 style="color: #fd6f00; border-bottom: 2px solid #fd6f00; padding-bottom: 10px; margin-top: 0;">New Inquiry Received</h2>
        <p style="margin: 10px 0;"><strong>Sender Name:</strong> ${name}</p>
        <p style="margin: 10px 0;"><strong>Sender Email:</strong> <a href="mailto:${email}">${email}</a></p>
        <p style="margin: 10px 0;"><strong>Subject:</strong> ${subject}</p>
        <div style="background-color: #f9f9f9; padding: 15px; border-left: 4px solid #fd6f00; border-radius: 4px; margin-top: 15px;">
          <p style="white-space: pre-wrap; margin: 0; line-height: 1.5; font-size: 14px;">${message}</p>
        </div>
        <p style="font-size: 11px; color: #888; margin-top: 20px; text-align: center; border-top: 1px solid #eee; padding-top: 10px;">
          Sent from Prankur Sagar's Personal Portfolio Server.
        </p>
      </div>
    `
  };

  if (mailTransporter) {
    try {
      await mailTransporter.sendMail(mailOptions);
      console.log(`Email successfully dispatched to ${EMAIL_TO}`);
      return true;
    } catch (err) {
      console.error('Nodemailer failed to send email:', err.message);
      return false;
    }
  } else {
    console.log('\n----------------- SIMULATED EMAIL -----------------');
    console.log(`To: ${EMAIL_TO}`);
    console.log(`From: ${email}`);
    console.log(`Subject: New Portfolio Inquiry: ${subject}`);
    console.log(`Body:\n${message}`);
    console.log('---------------------------------------------------\n');
    console.log('Note: SMTP credentials not set in .env. Email simulation completed successfully.');
    return true;
  }
}

// Use standard middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database File Configuration
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'inquiries.json');

// Ensure data folder and file exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify([], null, 2), 'utf8');
}

// Helper functions for JSON database operations
function readInquiries() {
  try {
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading database file:', err);
    return [];
  }
}

function writeInquiries(inquiries) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(inquiries, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing to database file:', err);
    return false;
  }
}

// Simple Admin Authentication Middleware
function authenticateAdmin(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  const token = authHeader.split(' ')[1]; // "Bearer <token>"
  if (token === SESSION_SECRET) {
    next();
  } else {
    return res.status(403).json({ error: 'Access denied. Invalid token.' });
  }
}

// --- API ROUTES ---

// 1. Submit contact inquiry
app.post('/api/contact', (req, res) => {
  const { name, email, subject, message } = req.body;

  // Basic validation
  if (!name || !email || !subject || !message) {
    return res.status(400).json({ error: 'All fields (name, email, subject, message) are required.' });
  }

  // Simple email format check
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  const inquiries = readInquiries();
  
  const newInquiry = {
    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
    name: name.trim(),
    email: email.trim(),
    subject: subject.trim(),
    message: message.trim(),
    date: new Date().toISOString(),
    status: 'unread' // 'unread' or 'read'
  };

  inquiries.push(newInquiry);
  
  if (writeInquiries(inquiries)) {
    // Send email notification (asynchronous, doesn't block client response)
    sendEmailNotification(name.trim(), email.trim(), subject.trim(), message.trim());
    
    res.status(201).json({ success: true, message: 'Inquiry submitted successfully.' });
  } else {
    res.status(500).json({ error: 'Failed to save message. Please try again later.' });
  }
});

// 2. Admin Login
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;

  if (!password) {
    return res.status(400).json({ error: 'Password is required.' });
  }

  if (password === ADMIN_PASSWORD) {
    // Generate a simple token (SESSION_SECRET acts as token for simplicity)
    res.json({ success: true, token: SESSION_SECRET });
  } else {
    res.status(401).json({ error: 'Invalid password. Access denied.' });
  }
});

// 3. Get all inquiries (protected)
app.get('/api/admin/inquiries', authenticateAdmin, (req, res) => {
  const inquiries = readInquiries();
  // Sort by date descending (newest first)
  const sorted = inquiries.sort((a, b) => new Date(b.date) - new Date(a.date));
  res.json(sorted);
});

// 4. Update inquiry status (protected)
app.put('/api/admin/inquiries/:id', authenticateAdmin, (req, res) => {
  const { id } = req.params;
  const { status } = req.body; // 'read' or 'unread'

  if (!status || !['read', 'unread'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status. Must be "read" or "unread".' });
  }

  let inquiries = readInquiries();
  const inquiryIndex = inquiries.findIndex(item => item.id === id);

  if (inquiryIndex === -1) {
    return res.status(404).json({ error: 'Inquiry not found.' });
  }

  inquiries[inquiryIndex].status = status;

  if (writeInquiries(inquiries)) {
    res.json({ success: true, message: `Inquiry status updated to ${status}.` });
  } else {
    res.status(500).json({ error: 'Failed to update status.' });
  }
});

// 5. Delete an inquiry (protected)
app.delete('/api/admin/inquiries/:id', authenticateAdmin, (req, res) => {
  const { id } = req.params;

  let inquiries = readInquiries();
  const filtered = inquiries.filter(item => item.id !== id);

  if (inquiries.length === filtered.length) {
    return res.status(404).json({ error: 'Inquiry not found.' });
  }

  if (writeInquiries(filtered)) {
    res.json({ success: true, message: 'Inquiry deleted successfully.' });
  } else {
    res.status(500).json({ error: 'Failed to delete inquiry.' });
  }
});

// For any other routes, serve index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`==================================================`);
  console.log(`Portfolio Server is running locally!`);
  console.log(`Access the website: http://localhost:${PORT}`);
  console.log(`Access Admin Dashboard: http://localhost:${PORT}/admin.html`);
  console.log(`==================================================`);
});
