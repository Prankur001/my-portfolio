const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

const srcDir = __dirname;
const destZip = path.join(path.dirname(srcDir), 'portfolio-website.zip');

console.log(`Initializing project compression...`);
console.log(`Source Directory: ${srcDir}`);
console.log(`Destination ZIP: ${destZip}`);

// Clean up existing zip if any
if (fs.existsSync(destZip)) {
  try {
    fs.unlinkSync(destZip);
    console.log('Removed existing old ZIP file.');
  } catch (err) {
    console.error('Warning: Could not remove old ZIP file.', err.message);
  }
}

// Construct Windows PowerShell Compress-Archive command.
// We exclude node_modules and data folders to keep the ZIP size minimal and clean.
// The user can run 'npm install' when they unpack the project.
// We use -Path to specify files, but excluding node_modules is best done by building the list of items.
const items = fs.readdirSync(srcDir)
  .filter(item => item !== 'node_modules' && item !== 'data' && !item.startsWith('.'))
  .map(item => path.join(srcDir, item));

// Escape paths for PowerShell array syntax
const psPaths = items.map(p => `'${p}'`).join(', ');

const cmd = `powershell -Command "Compress-Archive -Path ${psPaths} -DestinationPath '${destZip}' -Force"`;

console.log('Compressing files (excluding node_modules and data logs)...');

exec(cmd, (err, stdout, stderr) => {
  if (err) {
    console.error('\nCompression Failed!');
    console.error(err.message);
    console.error(stderr);
    process.exit(1);
  }
  console.log('\n==================================================');
  console.log('PROJECT COMPRESSED SUCCESSFULLY!');
  console.log(`ZIP file created: ${destZip}`);
  console.log('You can now download this ZIP to deploy the project.');
  console.log('==================================================');
});
