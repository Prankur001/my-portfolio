document.addEventListener('DOMContentLoaded', () => {
  
  // ==========================================
  // 1. MOBILE NAVIGATION MENU TOGGLE
  // ==========================================
  const navMenu = document.getElementById('nav-menu');
  const navToggle = document.getElementById('nav-toggle');
  const navClose = document.getElementById('nav-close');
  const navLinks = document.querySelectorAll('.nav-link');

  if (navToggle) {
    navToggle.addEventListener('click', () => {
      navMenu.classList.add('show-menu');
    });
  }

  if (navClose) {
    navClose.addEventListener('click', () => {
      navMenu.classList.remove('show-menu');
    });
  }

  // Close menu when a link is clicked
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('show-menu');
    });
  });

  // ==========================================
  // 2. STICKY HEADER & SCROLL SPY
  // ==========================================
  const header = document.getElementById('header');
  const sections = document.querySelectorAll('section[id]');

  function scrollHeader() {
    if (window.scrollY >= 50) {
      header.style.boxShadow = '0 4px 20px rgba(0,0,0,0.3)';
      header.style.backgroundColor = 'rgba(18, 18, 18, 0.95)';
    } else {
      header.style.boxShadow = 'none';
      header.style.backgroundColor = 'rgba(18, 18, 18, 0.85)';
    }
  }
  window.addEventListener('scroll', scrollHeader);

  function scrollActiveLink() {
    const scrollY = window.scrollY;

    sections.forEach(current => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop - 120;
      const sectionId = current.getAttribute('id');
      const activeLink = document.querySelector(`.nav-menu a[href*=${sectionId}]`);

      if (activeLink) {
        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
          activeLink.classList.add('active-link');
        } else {
          activeLink.classList.remove('active-link');
        }
      }
    });
  }
  window.addEventListener('scroll', scrollActiveLink);

  // ==========================================
  // 3. STATS COUNT-UP ANIMATION
  // ==========================================
  const stats = document.querySelectorAll('.stat-number');
  let animatedStats = false;

  function countUp(element) {
    const target = parseInt(element.getAttribute('data-target'), 10);
    const duration = 2000; // 2 seconds duration
    const stepTime = Math.abs(Math.floor(duration / target));
    let current = 0;

    // Special logic for B.Tech CGPA display static text
    if (element.textContent.includes('7.23')) {
      element.textContent = '7.23/10';
      return;
    }

    const timer = setInterval(() => {
      current += 1;
      element.textContent = current + '+';
      if (current >= target) {
        element.textContent = target + '+';
        clearInterval(timer);
      }
    }, stepTime);
  }

  const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !animatedStats) {
        stats.forEach(stat => countUp(stat));
        animatedStats = true;
      }
    });
  }, { threshold: 0.5 });

  const heroSection = document.querySelector('.hero');
  if (heroSection) {
    statsObserver.observe(heroSection);
  }

  // ==========================================
  // 4. ABOUT SKILLS FILL-UP ANIMATION
  // ==========================================
  const progressFills = document.querySelectorAll('.progress-fill');
  let animatedSkills = false;

  function animateSkills() {
    progressFills.forEach(fill => {
      const progress = fill.getAttribute('data-progress');
      fill.style.width = progress;
    });
  }

  const skillsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !animatedSkills) {
        animateSkills();
        animatedSkills = true;
      }
    });
  }, { threshold: 0.2 });

  const aboutSection = document.querySelector('.about');
  if (aboutSection) {
    skillsObserver.observe(aboutSection);
  }

  // ==========================================
  // 5. PORTFOLIO FILTERING
  // ==========================================
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Toggle active buttons
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      projectCards.forEach(card => {
        const categories = card.getAttribute('data-category').split(' ');
        
        if (filterValue === 'all' || categories.includes(filterValue)) {
          card.style.display = 'block';
          // Fade in animation trigger
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
          }, 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'scale(0.8)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 300);
        }
      });
    });
  });

  // ==========================================
  // 6. PORTFOLIO MODAL (POPUP DETAILS)
  // ==========================================
  // Prankur Sagar's Real Academic Project Cases
  const projectsData = {
    p1: {
      title: "RTL Implementation of RISC-V Single Cycle Microarchitecture",
      category: "VLSI & Digital Design",
      desc: "Designed and implemented a single-cycle RISC-V processor core microarchitecture using Verilog. Developed and integrated core hardware blocks including the Arithmetic Logic Unit (ALU), Control Unit, Register File registers matrix, and Program Counter datapath. Successfully verified functionalities and instruction execution logic using Xilinx Vivado testbench environments.",
      client: "VLSI / Digital Design",
      date: "4 Months",
      tech: "Verilog RTL, Xilinx Vivado",
      bgClass: "p-bg-1",
      demoUrl: "#"
    },
    p2: {
      title: "CMOS Layout Design using Cadence Virtuoso",
      category: "VLSI Design",
      desc: "Conducted complete physical layouts for analog and digital VLSI circuits in Cadence Virtuoso. Created customized layouts for CMOS logic gates, ROM arrays, and a 6T Static RAM (SRAM) memory cell structure. Performed intensive Design Rule Check (DRC) and Layout Versus Schematic (LVS) verifications followed by post-layout extraction and simulations.",
      client: "VLSI Design / Layout",
      date: "5 Months",
      tech: "Cadence Virtuoso, DRC/LVS, Analog Design",
      bgClass: "p-bg-2",
      demoUrl: "#"
    },
    p3: {
      title: "Semiconductor Device Simulation using Silvaco TCAD",
      category: "VLSI Device Engineering",
      desc: "Constructed numerical device simulations for microelectronics architectures using Silvaco TCAD. Modeled Bipolar Junction Transistor (BJT) junctions and advanced field-effect configurations like Partially-Depleted (PD-SOI) and Fully-Depleted (FD-SOI) SOI MOSFETs. Evaluated essential device metrics including transfer curves, output characteristics, Drain-Induced Barrier Lowering (DIBL), and short-channel effects.",
      client: "Device Engineering",
      date: "4 Months",
      tech: "Silvaco TCAD, SOI Technology, Device Modeling",
      bgClass: "p-bg-3",
      demoUrl: "#"
    },
    p4: {
      title: "Design and Analysis of Microstrip Antennas",
      category: "RF / Microwave Design",
      desc: "Designed and simulated patch antennas on ANSYS HFSS. Engineered a Dual-Beam U-Slot and Circular Microstrip antenna employing an Arc-Shaped Defected Ground Structure (DGS) for bandwidth improvement. Extracted and optimized parameters: VSWR, return loss (S11), bandwidth matrices, power gain, and multi-directional radiation patterns.",
      client: "RF / Microwave Design",
      date: "5 Months",
      tech: "Ansys HFSS, DGS, Electromagnetic Solver",
      bgClass: "p-bg-4",
      demoUrl: "#"
    },
    p5: {
      title: "MMIC Power Amplifier Design",
      category: "RF Design",
      desc: "Engineered a Monolithic Microwave Integrated Circuit (MMIC) RF power amplifier in Keysight ADS (Advanced Design System). Extracted microstrip impedances, established high-gain DC bias networks, and verified unconditional stability limits across broad frequency bands using Scattering parameters (S-parameter) analysis and source/load pull methods.",
      client: "RF Simulation",
      date: "1 Week",
      tech: "Keysight ADS, S-Parameters, RF Amplifier",
      bgClass: "p-bg-5",
      demoUrl: "#"
    },
    p6: {
      title: "MecQuick Roadside Assistance Platform",
      category: "Software & Entrepreneurship",
      desc: "Founded and developed MecQuick, an on-demand digital platform focused on streamlining roadside vehicle breakdown support. Coordinates geolocations to map nearby certified auto-mechanics. Optimizes service response tracking, provides direct route mapping, and increases garage service accessibility.",
      client: "Independent / Startup",
      date: "Ongoing Development",
      tech: "HTML5, CSS, Python, Geolocation APIs",
      bgClass: "p-bg-6",
      demoUrl: "#"
    }
  };

  const modal = document.getElementById('project-modal');
  const modalClose = document.getElementById('modal-close-btn');
  const viewDetailsBtns = document.querySelectorAll('.view-details-btn');
  
  // Modal Fields
  const mImg = document.getElementById('modal-project-img');
  const mCategory = document.getElementById('modal-project-category');
  const mTitle = document.getElementById('modal-project-title');
  const mDesc = document.getElementById('modal-project-desc');
  const mClient = document.getElementById('modal-project-client');
  const mDate = document.getElementById('modal-project-date');
  const mTech = document.getElementById('modal-project-tech');
  const mLink = document.getElementById('modal-project-link');

  function openModal(projectId) {
    const data = projectsData[projectId];
    if (!data) return;

    // Reset and hydtrate image placeholder class
    mImg.className = 'modal-placeholder-img ' + data.bgClass;
    // Set text elements
    mCategory.textContent = data.category;
    mTitle.textContent = data.title;
    mDesc.textContent = data.desc;
    mClient.textContent = data.client;
    mDate.textContent = data.date;
    mTech.textContent = data.tech;
    mLink.href = data.demoUrl;

    // Load custom simulator playground if it matches a themed ECE/Startup project
    initPlayground(projectId);

    modal.classList.add('open');
    document.body.style.overflow = 'hidden'; // Stop background scrolling
  }

  function closeModal() {
    modal.classList.remove('open');
    document.body.style.overflow = ''; // Enable scrolling
    destroyActivePlayground();
  }

  // Attach card click handlers
  projectCards.forEach(card => {
    const cardId = card.getAttribute('data-id');
    const viewBtn = card.querySelector('.view-details-btn');
    
    // Clicking either button or card body triggers modal
    if (viewBtn) {
      viewBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openModal(cardId);
      });
    }
    card.addEventListener('click', () => {
      openModal(cardId);
    });
  });

  if (modalClose) {
    modalClose.addEventListener('click', closeModal);
  }

  // Close modal clicking on overlay background
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal();
      }
    });
  }

  // Escape key closes modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closeModal();
    }
  });

  // ==========================================
  // 7. CONTACT FORM SUBMISSION TO API
  // ==========================================
  const contactForm = document.getElementById('contact-form');
  const submitBtn = document.getElementById('form-submit-btn');
  const btnTxt = submitBtn.querySelector('.btn-txt');
  const btnSpinner = submitBtn.querySelector('.btn-spinner');
  const contactAlert = document.getElementById('contact-alert');
  const transceiverPanelElement = document.querySelector('.transceiver-panel');

  function showAlert(message, type) {
    contactAlert.textContent = message;
    contactAlert.className = `alert alert-${type}`;
    contactAlert.classList.remove('hidden');
    
    // Automatically hide alert after 5 seconds
    setTimeout(() => {
      contactAlert.classList.add('hidden');
    }, 5000);
  }

  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const name = document.getElementById('form-name').value;
      const email = document.getElementById('form-email').value;
      const subject = document.getElementById('form-subject').value;
      const message = document.getElementById('form-message').value;

      // Trigger loading states and transceiver submitting burst
      submitBtn.disabled = true;
      btnTxt.classList.add('hidden');
      btnSpinner.classList.remove('hidden');
      contactAlert.classList.add('hidden');
      
      isTransmitting = true;
      if (transceiverPanelElement) {
        transceiverPanelElement.classList.add('submitting-burst');
      }
      
      const linkStatusEl = document.getElementById('link-status');
      const rssiValEl = document.getElementById('rssi-val');
      
      if (linkStatusEl) {
        linkStatusEl.textContent = 'TRANSMITTING';
        linkStatusEl.style.color = '#00ffff';
      }
      if (rssiValEl) {
        rssiValEl.textContent = '-10 dBm';
      }

      try {
        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ name, email, subject, message })
        });

        const data = await response.json();

        if (response.ok) {
          showAlert('Thank you! Your message was submitted successfully.', 'success');
          
          if (linkStatusEl) {
            linkStatusEl.textContent = 'SENT (ACK)';
            linkStatusEl.style.color = '#2ecc71';
          }
          if (rssiValEl) {
            rssiValEl.textContent = '-8 dBm';
          }
          
          contactForm.reset();
          if (typeof updateFieldLogicStates === 'function') {
            updateFieldLogicStates(); // Reset logic indicators
          }
          
          // Keep transceiver animation active for a burst period, then revert
          setTimeout(() => {
            if (transceiverPanelElement) {
              transceiverPanelElement.classList.remove('submitting-burst');
            }
            isTransmitting = false;
          }, 4000);
          
        } else {
          showAlert(data.error || 'Something went wrong. Please check your inputs.', 'danger');
          if (transceiverPanelElement) {
            transceiverPanelElement.classList.remove('submitting-burst');
          }
          isTransmitting = false;
        }
      } catch (err) {
        console.error('Contact submission error:', err);
        showAlert('Could not connect to the server. Please check if the backend is running.', 'danger');
        if (transceiverPanelElement) {
          transceiverPanelElement.classList.remove('submitting-burst');
        }
        isTransmitting = false;
      } finally {
        // Clear loading states
        submitBtn.disabled = false;
        btnTxt.classList.remove('hidden');
        btnSpinner.classList.add('hidden');
      }
    });
  }

  // ==========================================
  // 8. SIMULATE CV DOWNLOAD (PRANKUR SAGAR FULL RESUME)
  // ==========================================
  const cvBtn = document.getElementById('download-cv-btn');
  if (cvBtn) {
    cvBtn.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Simulate file download by creating a temporary link to a mock CV text file
      const cvText = `
PRANKUR SAGAR
=====================================================================
Email: prankursagar@ece.du.ac.in | Phone: +91-7055599026
LinkedIn: linkedin.com/in/prankur-s-b34643288
Address: New Delhi

EDUCATION
---------------------------------------------------------------------
- B.Tech in Electronics & Communication Engineering (2023 - 2027)
  Faculty of Technology, University of Delhi | CGPA: 7.23 / 10
- Class XII (UP Board) | Saraswati Vidya Mandir (2022) | Percentage: 82.6%
- Class X (UP Board) | Saraswati Vidya Mandir (2020) | Percentage: 86.0%

SIGNIFICANT ACHIEVEMENTS
---------------------------------------------------------------------
- Secured 3rd Position among 18 competing teams in LineTrek - Line Following Robot Competition at Faculty of Technology, University of Delhi (2026).
- Qualified the National Defence Academy (NDA) written examination conducted by UPSC and participated multiple times in Services Selection Board selection process.

ACADEMIC PROJECTS
---------------------------------------------------------------------
1. RTL Implementation of RISC-V Single Cycle Microarchitecture (Processor Design)
   Technologies: Verilog, Xilinx Vivado (Duration: 4 Months)
   - Developed and integrated key processor modules including ALU, Control Unit, Register File, and Datapath.
   - Verified processor functionality through simulation and testbench validation using Xilinx Vivado.
   
2. CMOS Layout Design using Cadence Virtuoso (VLSI Design)
   Technologies: Cadence Virtuoso, CMOS Design (Duration: 5 Months)
   - Designed CMOS logic gates, ROM arrays, and 6T SRAM cell layouts using Cadence Virtuoso.
   - Performed DRC/LVS verification and post-layout simulations for functional validation.

3. Semiconductor Device Simulation using Silvaco TCAD (VLSI Device Engineering)
   Technologies: Silvaco TCAD, CMOS Device Modeling, SOI Technology (Duration: 4 Months)
   - Simulated BJT and advanced MOSFET structures including PD-SOI and FD-SOI devices using TCAD.
   - Evaluated transfer/output characteristics, DIBL, and short-channel effects through TCAD-based semiconductor device analysis.

4. Design and Analysis of Microstrip Antennas using Ansys HFSS (RF/Microwave Design)
   Technologies: Ansys HFSS, DGS, Microstrip Antenna Design (Duration: 5 Months)
   - Designed and simulated Dual-Beam U-Slot & Circular Microstrip antenna employing Arc-Shaped Defected Ground Structure (DGS) using ANSYS HFSS.
   - Analyzed antenna performance parameters including gain, bandwidth, VSWR, return loss (S11), and radiation characteristics.

5. MMIC Power Amplifier Design using Keysight ADS (RF Design)
   Technologies: Keysight ADS, RF Simulation (Duration: 1 Week)
   - Designed an RF power amplifier achieving high gain and unconditional stability.
   - Conducted S-parameter analysis and optimized the circuit for RF performance enhancement.

TECHNICAL SKILLS
---------------------------------------------------------------------
- Programming Languages: C, C++, Python
- Core Concepts: Data Structures & Algorithms, CMOS Design, Semiconductor Devices
- VLSI & EDA Tools: Cadence Virtuoso, Xilinx Vivado, Silvaco TCAD, Verilog
- Simulation Tools: MATLAB, LTSpice, NI Multisim, Ansys HFSS, CST Studio, Keysight ADS
- Embedded Systems: Arduino, ESP32, IoT Systems
- Other Tools: Git, Linux (Basic), LaTeX

CERTIFICATIONS & COURSES
---------------------------------------------------------------------
- Completed a certification workshop on RISC-V Processor & Neuromorphic Computing conducted by the Department of ECE, IIT Roorkee.
- Relevant Coursework: Analog & Digital Electronics, Digital & Analog VLSI Design, Microelectronics Design, Signals and Systems, Control Systems, Electromagnetic Theory, DSP, Communication Systems, Embedded Systems.

LEADERSHIP & ENTREPRENEURSHIP
---------------------------------------------------------------------
- Founder & Developer - MecQuick: Currently developing a roadside assistance platform focused on on-demand mechanic support, optimized response tracking, and faster service accessibility.
      `;
      
      const blob = new Blob([cvText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.href = url;
      tempLink.download = 'Prankur_Sagar_Resume.txt';
      document.body.appendChild(tempLink);
      tempLink.click();
      document.body.removeChild(tempLink);
      URL.revokeObjectURL(url);
    });
  }

  // ==========================================
  // 9. SCROLL REVEAL & PROGRESS INDICATOR
  // ==========================================
  
  // Dynamic Scroll Progress Indicator
  const scrollProgressBar = document.getElementById('scroll-progress');
  
  function updateScrollProgress() {
    if (!scrollProgressBar) return;
    const windowScroll = document.body.scrollTop || document.documentElement.scrollTop;
    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = height > 0 ? (windowScroll / height) * 100 : 0;
    scrollProgressBar.style.width = scrolled + '%';
  }
  
  window.addEventListener('scroll', updateScrollProgress);
  updateScrollProgress(); // Initial check

  // Enhanced Intersection Observer for Scroll Reveals
  const revealElements = document.querySelectorAll('.reveal, .reveal-oscilloscope, .reveal-bus-shift, .reveal-cmos-switch, .reveal-rf-radiate');
  
  if (revealElements.length > 0) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
          revealObserver.unobserve(entry.target); // Animate once
        }
      });
    }, {
      threshold: 0.08, // Trigger earlier for rapid scrolling
      rootMargin: "0px 0px -80px 0px" // Trigger before scrolling completely in
    });

    revealElements.forEach(el => {
      revealObserver.observe(el);
    });
  }  // ==========================================
  // 10. VLSI LAYOUT CANVAS ANIMATION
  // ==========================================
  const canvas = document.getElementById('vlsi-canvas-bg');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;
    
    // Grid Configuration
    const gridSize = 70; // Manhattan grid spacing
    let cols = Math.ceil(width / gridSize);
    let rows = Math.ceil(height / gridSize);
    
    // Track mouse
    let mouse = { x: -1000, y: -1000, active: false };
    
    // Resize handler
    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      cols = Math.ceil(width / gridSize);
      rows = Math.ceil(height / gridSize);
    });
    
    window.addEventListener('mousemove', (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.active = true;
    });
    
    window.addEventListener('mouseleave', () => {
      mouse.active = false;
    });
    
    // Particle (Electron) Class
    class Particle {
      constructor() {
        this.reset();
      }
      
      reset() {
        // Start at a grid junction
        this.col = Math.floor(Math.random() * cols);
        this.row = Math.floor(Math.random() * rows);
        this.x = this.col * gridSize;
        this.y = this.row * gridSize;
        
        // Target junction
        this.targetX = this.x;
        this.targetY = this.y;
        
        this.speed = 1.6 + Math.random() * 2.0; // Increased speed for more active flow
        this.progress = 0;
        
        // Directions: 0=East, 1=South, 2=West, 3=North (Manhattan routing)
        this.dir = Math.floor(Math.random() * 4);
        
        // Pre-seed trace history immediately so paths draw from frame 1
        this.history = [
          { x: this.x, y: this.y },
          { x: this.x, y: this.y }
        ];
        this.maxHistory = 15 + Math.floor(Math.random() * 20);
        
        this.color = Math.random() > 0.4 ? '#fd6f00' : '#ff8c00'; // Orange/gold copper traces
        this.setNextTarget();
      }
      
      setNextTarget() {
        this.col = Math.round(this.x / gridSize);
        this.row = Math.round(this.y / gridSize);
        
        // Save current position to history
        this.history.push({ x: this.x, y: this.y });
        if (this.history.length > this.maxHistory) {
          this.history.shift();
        }
        
        // Decide next turn (Manhattan routing)
        const possibleDirs = [];
        
        // Check valid neighboring grid junctions
        if (this.col < cols - 1) possibleDirs.push(0); // East
        if (this.row < rows - 1) possibleDirs.push(1); // South
        if (this.col > 0) possibleDirs.push(2); // West
        if (this.row > 0) possibleDirs.push(3); // North
        
        const backDir = (this.dir + 2) % 4;
        const forwardDirs = possibleDirs.filter(d => d !== backDir);
        
        if (forwardDirs.length > 0) {
          if (Math.random() < 0.85) {
            this.dir = forwardDirs[Math.floor(Math.random() * forwardDirs.length)];
          } else {
            this.dir = possibleDirs[Math.floor(Math.random() * possibleDirs.length)];
          }
        } else if (possibleDirs.length > 0) {
          this.dir = possibleDirs[Math.floor(Math.random() * possibleDirs.length)];
        } else {
          this.reset();
          return;
        }
        
        // Set target coordinate
        if (this.dir === 0) this.targetX = (this.col + 1) * gridSize;
        if (this.dir === 1) this.targetY = (this.row + 1) * gridSize;
        if (this.dir === 2) this.targetX = (this.col - 1) * gridSize;
        if (this.dir === 3) this.targetY = (this.row - 1) * gridSize;
      }
      
      update() {
        const dx = this.targetX - this.x;
        const dy = this.targetY - this.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist < this.speed) {
          this.x = this.targetX;
          this.y = this.targetY;
          this.setNextTarget();
        } else {
          this.x += (dx / dist) * this.speed;
          this.y += (dy / dist) * this.speed;
        }
      }
      
      draw() {
        if (this.history.length < 2) return;
        
        // Draw history path (metal interconnect wire traces)
        ctx.beginPath();
        ctx.moveTo(this.history[0].x, this.history[0].y);
        for (let i = 1; i < this.history.length; i++) {
          ctx.lineTo(this.history[i].x, this.history[i].y);
        }
        ctx.lineTo(this.x, this.y);
        
        ctx.strokeStyle = this.color;
        ctx.lineWidth = 1.5; // Thicker lines
        ctx.stroke();
        
        // Draw signal charge packet (glowing via contact node)
        ctx.beginPath();
        ctx.arc(this.x, this.y, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.shadowBlur = 8;
        ctx.shadowColor = this.color;
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    }
    
    // Initialize Particles
    const particles = [];
    const maxParticles = 22;
    for (let i = 0; i < maxParticles; i++) {
      particles.push(new Particle());
    }
    
    // Core Animation Loop
    function animate() {
      ctx.clearRect(0, 0, width, height);
      
      // Draw background layout grid lines
      ctx.strokeStyle = 'rgba(253, 111, 0, 0.02)';
      ctx.lineWidth = 0.5;
      
      for (let c = 0; c < cols; c++) {
        ctx.beginPath();
        ctx.moveTo(c * gridSize, 0);
        ctx.lineTo(c * gridSize, height);
        ctx.stroke();
      }
      for (let r = 0; r < rows; r++) {
        ctx.beginPath();
        ctx.moveTo(0, r * gridSize);
        ctx.lineTo(width, r * gridSize);
        ctx.stroke();
      }
      
      // Draw grid intersection via contacts
      for (let c = 0; c < cols; c++) {
        for (let r = 0; r < rows; r++) {
          if ((c + r) % 6 === 0 && Math.sin(Date.now() * 0.001 + c) > 0.85) {
            ctx.beginPath();
            ctx.rect(c * gridSize - 1, r * gridSize - 1, 2, 2);
            ctx.fillStyle = 'rgba(253, 111, 0, 0.25)';
            ctx.fill();
          }
        }
      }
      
      // Draw dynamic mouse grid line interactions
      if (mouse.active) {
        const mouseCol = Math.round(mouse.x / gridSize);
        const mouseRow = Math.round(mouse.y / gridSize);
        
        ctx.strokeStyle = 'rgba(253, 111, 0, 0.06)';
        ctx.lineWidth = 0.5;
        
        ctx.beginPath();
        ctx.moveTo(0, mouseRow * gridSize);
        ctx.lineTo(width, mouseRow * gridSize);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(mouseCol * gridSize, 0);
        ctx.lineTo(mouseCol * gridSize, height);
        ctx.stroke();
      }
      
      // Update & Draw electron particles
      particles.forEach(p => {
        p.update();
        p.draw();
      });
      
      requestAnimationFrame(animate);
    }
    
    animate();
  }

  
  // ==========================================
  // 11. VLSI CMOS SIMULATION LAB LOGIC
  // ==========================================
  const toggleInputBtn = document.getElementById('toggle-input-btn');
  const pmosNode = document.getElementById('pmos-node');
  const pmosState = document.getElementById('pmos-state');
  const nmosNode = document.getElementById('nmos-node');
  const nmosState = document.getElementById('nmos-state');
  const outputBadge = document.getElementById('output-badge');
  const scopeCanvas = document.getElementById('oscilloscope-canvas');
  
  if (toggleInputBtn && scopeCanvas) {
    let inputState = 0;
    let outputState = 1;
    
    // Toggle CMOS logic state
    toggleInputBtn.addEventListener('click', () => {
      inputState = inputState === 0 ? 1 : 0;
      outputState = inputState === 0 ? 1 : 0;
      
      // Update toggle button UI
      toggleInputBtn.textContent = `Input Logic: ${inputState}`;
      
      // Update output badge UI
      outputBadge.textContent = `Output Logic: ${outputState}`;
      if (outputState === 1) {
        outputBadge.classList.add('high-state');
      } else {
        outputBadge.classList.remove('high-state');
      }
      
      // Toggle PMOS state
      if (inputState === 0) {
        pmosNode.className = 'transistor-node state-on';
        pmosState.textContent = 'ON (Conducting)';
        nmosNode.className = 'transistor-node state-off';
        nmosState.textContent = 'OFF (Cutoff)';
      } else {
        pmosNode.className = 'transistor-node state-off';
        pmosState.textContent = 'OFF (Cutoff)';
        nmosNode.className = 'transistor-node state-on';
        nmosState.textContent = 'ON (Conducting)';
      }
    });
    
    // Oscilloscope Animation Setup
    const scopeCtx = scopeCanvas.getContext('2d');
    
    // Adjust canvas resolution dynamically
    let scopeWidth = scopeCanvas.width = scopeCanvas.parentElement.clientWidth;
    let scopeHeight = scopeCanvas.height = scopeCanvas.parentElement.clientHeight;
    
    window.addEventListener('resize', () => {
      if (scopeCanvas.parentElement) {
        scopeWidth = scopeCanvas.width = scopeCanvas.parentElement.clientWidth;
        scopeHeight = scopeCanvas.height = scopeCanvas.parentElement.clientHeight;
      }
    });
    
    // Logic levels history buffers
    const bufferSize = 250;
    const inputHistory = new Array(bufferSize).fill(0);
    const outputHistory = new Array(bufferSize).fill(1);
    
    function animateScope() {
      // Shift array data leftwards to simulate real-time scroll
      inputHistory.shift();
      inputHistory.push(inputState);
      
      outputHistory.shift();
      outputHistory.push(outputState);
      
      scopeCtx.clearRect(0, 0, scopeWidth, scopeHeight);
      
      // 1. Draw Oscilloscope Grid Lines (analog style)
      scopeCtx.strokeStyle = '#181818';
      scopeCtx.lineWidth = 0.5;
      
      const gridSpacing = 25;
      for (let x = 0; x < scopeWidth; x += gridSpacing) {
        scopeCtx.beginPath();
        scopeCtx.moveTo(x, 0);
        scopeCtx.lineTo(x, scopeHeight);
        scopeCtx.stroke();
      }
      for (let y = 0; y < scopeHeight; y += gridSpacing) {
        scopeCtx.beginPath();
        scopeCtx.moveTo(0, y);
        scopeCtx.lineTo(scopeWidth, y);
        scopeCtx.stroke();
      }
      
      // Draw grid center axis dividers
      scopeCtx.strokeStyle = '#2b2b2b';
      scopeCtx.lineWidth = 1;
      
      scopeCtx.beginPath();
      scopeCtx.moveTo(0, scopeHeight / 2);
      scopeCtx.lineTo(scopeWidth, scopeHeight / 2);
      scopeCtx.stroke();
      
      scopeCtx.beginPath();
      scopeCtx.moveTo(scopeWidth / 2, 0);
      scopeCtx.lineTo(scopeWidth / 2, scopeHeight);
      scopeCtx.stroke();
      
      // Mappings: Map binary 0/1 states to vertical screen levels
      // Split the screen in two channels: Top for Input, Bottom for Output
      const ch1Y0 = scopeHeight * 0.45; // Input Logic 0 height
      const ch1Y1 = scopeHeight * 0.15; // Input Logic 1 height
      const ch2Y0 = scopeHeight * 0.85; // Output Logic 0 height
      const ch2Y1 = scopeHeight * 0.55; // Output Logic 1 height
      
      // Render labels
      scopeCtx.font = '10px Outfit';
      scopeCtx.fillStyle = '#fd6f00';
      scopeCtx.fillText('CH1 (V_in): 5.0V/div', 15, 20);
      scopeCtx.fillStyle = '#2ecc71';
      scopeCtx.fillText('CH2 (V_out): 5.0V/div', 15, scopeHeight / 2 + 20);
      
      // 2. Draw Input Channel (V_in) trace line (Yellow/Orange)
      scopeCtx.beginPath();
      scopeCtx.strokeStyle = '#fd6f00';
      scopeCtx.lineWidth = 2.0;
      
      let step = scopeWidth / (bufferSize - 1);
      for (let i = 0; i < bufferSize; i++) {
        const val = inputHistory[i];
        const targetY = val === 1 ? ch1Y1 : ch1Y0;
        const xPos = i * step;
        
        if (i === 0) {
          scopeCtx.moveTo(xPos, targetY);
        } else {
          // Draw sharp square transitions (Manhattan layout digital rise/fall)
          const prevVal = inputHistory[i - 1];
          const prevTargetY = prevVal === 1 ? ch1Y1 : ch1Y0;
          if (prevTargetY !== targetY) {
            scopeCtx.lineTo(xPos, prevTargetY); // vertical rise/fall segment
          }
          scopeCtx.lineTo(xPos, targetY);
        }
      }
      scopeCtx.stroke();
      
      // 3. Draw Output Channel (V_out) trace line (Neon-Green)
      scopeCtx.beginPath();
      scopeCtx.strokeStyle = '#2ecc71';
      scopeCtx.lineWidth = 2.0;
      
      for (let i = 0; i < bufferSize; i++) {
        const val = outputHistory[i];
        const targetY = val === 1 ? ch2Y1 : ch2Y0;
        const xPos = i * step;
        
        if (i === 0) {
          scopeCtx.moveTo(xPos, targetY);
        } else {
          // Draw sharp square transitions (Manhattan layout digital rise/fall)
          const prevVal = outputHistory[i - 1];
          const prevTargetY = prevVal === 1 ? ch2Y1 : ch2Y0;
          if (prevTargetY !== targetY) {
            scopeCtx.lineTo(xPos, prevTargetY);
          }
          scopeCtx.lineTo(xPos, targetY);
        }
      }
      scopeCtx.stroke();
      
      requestAnimationFrame(animateScope);
    }
    
    animateScope();
  }

  // ==========================================
  // 14. RF TRANSCEIVER TELEMETRY FLUCTUATOR
  // ==========================================
  const rssiVal = document.getElementById('rssi-val');
  const linkStatus = document.getElementById('link-status');
  let isTransmitting = false; // Flag to hold visual updates during active send
  
  if (rssiVal && linkStatus) {
    let baseRssi = -45;
    
    setInterval(() => {
      if (isTransmitting) return; // Skip updating during transmission
      
      // Small fluctuations in RSSI signal strength (-42 to -48 dBm)
      const rssiOffset = Math.floor(Math.random() * 5 - 2);
      const finalRssi = baseRssi + rssiOffset;
      rssiVal.textContent = `${finalRssi} dBm`;
      
      // Randomly simulate block syncing states
      const rand = Math.random();
      if (rand > 0.88) {
        linkStatus.textContent = 'SYNCING';
        linkStatus.style.color = '#fd6f00'; // Orange sync
      } else {
        linkStatus.textContent = 'STABLE';
        linkStatus.style.color = '#2ecc71'; // Green stable link
      }
    }, 2500);
  }

  // ==========================================
  // 15. SILICON GATE LOGIC FIELDS INTERACTION
  // ==========================================
  const transceiverPanel = document.querySelector('.transceiver-panel');
  const formFieldsList = ['form-name', 'form-email', 'form-subject', 'form-message'];
  
  function updateFieldLogicStates() {
    formFieldsList.forEach(id => {
      const input = document.getElementById(id);
      const labelId = `status-${id.replace('form-', '')}`;
      const statusLabel = document.getElementById(labelId);
      
      if (input && statusLabel) {
        const hasText = input.value.trim().length > 0;
        statusLabel.textContent = hasText ? '1' : '0';
        if (hasText) {
          statusLabel.classList.add('logic-high');
        } else {
          statusLabel.classList.remove('logic-high');
        }
      }
    });
  }

  // Bind input listeners and active focus trackers
  formFieldsList.forEach(id => {
    const input = document.getElementById(id);
    if (input) {
      input.addEventListener('input', updateFieldLogicStates);
      
      // Typing active triggers transceiver panel frequency speed-boost
      input.addEventListener('focus', () => {
        if (transceiverPanel) {
          transceiverPanel.classList.add('typing-active');
        }
        const labelId = `status-${id.replace('form-', '')}`;
        const statusLabel = document.getElementById(labelId);
        if (statusLabel) {
          statusLabel.style.borderColor = 'var(--primary)';
        }
      });
      
      input.addEventListener('blur', () => {
        // Micro delay to verify if focus shifted to another field node
        setTimeout(() => {
          const focusedElement = document.activeElement;
          const isStillFormNode = focusedElement && formFieldsList.includes(focusedElement.id);
          if (!isStillFormNode && transceiverPanel) {
            transceiverPanel.classList.remove('typing-active');
          }
        }, 100);
        
        const labelId = `status-${id.replace('form-', '')}`;
        const statusLabel = document.getElementById(labelId);
        if (statusLabel) {
          statusLabel.style.borderColor = '';
        }
        updateFieldLogicStates();
      });
    }
  });

  // Run initial scan to handle prefilled/cached input parameters
  setTimeout(updateFieldLogicStates, 500);

  // ==========================================
  // MODAL PLAYGROUNDS LIFECYCLE INTERACTION
  // ==========================================
  let activePlaygroundId = null;
  let activePlaygroundLoop = null;

  function initPlayground(projectId) {
    const container = document.getElementById('modal-playground-container');
    const defaultImg = document.getElementById('modal-project-img');
    
    if (!container || !defaultImg) return;
    
    // Clear any previous loop
    destroyActivePlayground();
    
    if (projectId === 'p1' || projectId === 'p4' || projectId === 'p6') {
      defaultImg.style.display = 'none';
      container.style.display = 'flex';
      activePlaygroundId = projectId;
      
      if (projectId === 'p1') {
        loadRiscvPlayground(container);
      } else if (projectId === 'p4') {
        loadAntennaPlayground(container);
      } else if (projectId === 'p6') {
        loadMecQuickPlayground(container);
      }
    } else {
      defaultImg.style.display = 'block';
      container.style.display = 'none';
    }
  }

  function destroyActivePlayground() {
    if (activePlaygroundLoop) {
      cancelAnimationFrame(activePlaygroundLoop);
      activePlaygroundLoop = null;
    }
    const container = document.getElementById('modal-playground-container');
    if (container) {
      container.innerHTML = '';
      container.style.display = 'none';
    }
    activePlaygroundId = null;
  }

  function loadAntennaPlayground(container) {
    container.innerHTML = `
      <div class="playground-header">
        <div class="playground-title"><i class="bx bx-broadcast"></i> Antenna Beamforming Lab</div>
        <div class="antenna-tuner-panel">
          <div class="tuner-control-row">
            <span class="tuner-label" style="font-family: var(--font-accent);">Frequency Select:</span>
            <div class="tuner-slider-wrapper">
              <input type="range" class="antenna-freq-slider" id="antenna-freq-input" min="1" max="3" step="1" value="2">
              <span class="freq-val-display" id="freq-val-display">5.8 GHz</span>
            </div>
          </div>
        </div>
      </div>
      <div class="antenna-playground">
        <canvas class="playground-canvas" id="antenna-canvas"></canvas>
        <div class="antenna-metrics-hud">
          <div class="metric-box">
            <span class="metric-lbl">Freq</span>
            <span class="metric-val highlight" id="antenna-m-freq">5.8 GHz</span>
          </div>
          <div class="metric-box">
            <span class="metric-lbl">Peak Gain</span>
            <span class="metric-val" id="antenna-m-gain">7.8 dBi</span>
          </div>
          <div class="metric-box">
            <span class="metric-lbl">VSWR</span>
            <span class="metric-val" id="antenna-m-vswr">1.12</span>
          </div>
          <div class="metric-box">
            <span class="metric-lbl">3dB Beam</span>
            <span class="metric-val" id="antenna-m-beam">42&deg;</span>
          </div>
        </div>
      </div>
    `;

    const canvas = document.getElementById('antenna-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const freqInput = document.getElementById('antenna-freq-input');
    const freqDisplay = document.getElementById('freq-val-display');
    const mFreq = document.getElementById('antenna-m-freq');
    const mGain = document.getElementById('antenna-m-gain');
    const mVswr = document.getElementById('antenna-m-vswr');
    const mBeam = document.getElementById('antenna-m-beam');

    let freqIndex = 2; // 1 = 2.4, 2 = 5.8, 3 = 28
    const freqConfigs = {
      1: { val: '2.4 GHz', gain: '5.2 dBi', vswr: '1.25', beam: '75°' },
      2: { val: '5.8 GHz', gain: '7.8 dBi', vswr: '1.12', beam: '42°' },
      3: { val: '28.0 GHz', gain: '12.4 dBi', vswr: '1.45', beam: '12°' }
    };

    freqInput.addEventListener('input', (e) => {
      freqIndex = parseInt(e.target.value, 10);
      const config = freqConfigs[freqIndex];
      freqDisplay.textContent = config.val;
      mFreq.textContent = config.val;
      mGain.textContent = config.gain;
      mVswr.textContent = config.vswr;
      mBeam.textContent = config.beam;
    });

    let waveOffset = 0;
    
    function draw() {
      if (activePlaygroundId !== 'p4') return;
      
      let w = canvas.width = canvas.parentElement.clientWidth;
      let h = canvas.height = canvas.parentElement.clientHeight - 80; // offset metrics bar

      ctx.clearRect(0, 0, w, h);
      
      const centerX = w / 2;
      const centerY = h / 2 - 10;
      const maxRadius = Math.min(w, h) * 0.4;
      
      // 1. Draw polar grids
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      
      // Concentric circles
      for (let r = 0.2; r <= 1.0; r += 0.2) {
        ctx.beginPath();
        ctx.arc(centerX, centerY, maxRadius * r, 0, Math.PI * 2);
        ctx.stroke();
      }
      
      // Angle lines
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.font = '8px monospace';
      for (let angle = 0; angle < 360; angle += 30) {
        const rad = (angle * Math.PI) / 180;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX + Math.cos(rad) * maxRadius, centerY + Math.sin(rad) * maxRadius);
        ctx.stroke();
        
        // Draw labels
        const textX = centerX + Math.cos(rad) * (maxRadius + 12);
        const textY = centerY + Math.sin(rad) * (maxRadius + 12) + 3;
        ctx.fillText(angle + '°', textX - 8, textY);
      }
      
      // 2. Draw Radiation lobes
      ctx.shadowBlur = 10;
      ctx.shadowColor = 'var(--primary)';
      ctx.strokeStyle = 'var(--primary)';
      ctx.lineWidth = 2.5;
      
      ctx.beginPath();
      
      const steps = 360;
      for (let i = 0; i <= steps; i++) {
        const rad = (i * Math.PI) / 180;
        let rRatio = 0;
        
        // Match mathematical formulas to lobes
        if (freqIndex === 1) {
          // 2.4 GHz: Broad cardioid
          const relAngle = rad + Math.PI / 2;
          rRatio = 0.35 + 0.65 * Math.abs(Math.cos(relAngle));
        } else if (freqIndex === 2) {
          // 5.8 GHz: Directive
          const relAngle = rad + Math.PI / 2;
          rRatio = 0.85 * Math.pow(Math.max(0, Math.cos(relAngle)), 6) + 
                   0.15 * Math.abs(Math.cos(relAngle * 3)) * 0.4 +
                   0.12 * Math.max(0, Math.cos(relAngle + Math.PI)) * 0.6;
        } else {
          // 28.0 GHz: Very directive (pencil beam)
          const relAngle = rad + Math.PI / 2;
          rRatio = 0.9 * Math.pow(Math.max(0, Math.cos(relAngle)), 24) + 
                   0.1 * Math.abs(Math.sin(relAngle * 7)) * (0.6 - 0.5 * Math.abs(Math.sin(relAngle)));
        }
        
        rRatio = Math.max(0, Math.min(1, rRatio));
        const r = rRatio * maxRadius;
        const x = centerX + Math.cos(rad) * r;
        const y = centerY + Math.sin(rad) * r;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.closePath();
      ctx.stroke();
      ctx.fillStyle = 'rgba(253, 111, 0, 0.15)';
      ctx.fill();
      
      ctx.shadowBlur = 0;
      
      // 3. Draw active radiation wave arcs (animating outwards)
      waveOffset += 0.75;
      if (waveOffset > 40) waveOffset = 0;
      
      ctx.strokeStyle = 'rgba(0, 255, 255, 0.4)';
      ctx.lineWidth = 1.5;
      
      for (let w = 0; w < 3; w++) {
        const radius = (w * 35 + waveOffset) % 110;
        if (radius < 10) continue;
        
        const startRad = -Math.PI/2 - (freqIndex === 1 ? 0.6 : freqIndex === 2 ? 0.35 : 0.12);
        const endRad = -Math.PI/2 + (freqIndex === 1 ? 0.6 : freqIndex === 2 ? 0.35 : 0.12);
        
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius * (maxRadius / 100), startRad, endRad);
        ctx.stroke();
      }
      
      // 4. Draw Antenna Patch Node at center
      ctx.beginPath();
      ctx.rect(centerX - 8, centerY - 8, 16, 16);
      ctx.fillStyle = '#222';
      ctx.strokeStyle = '#00ffff';
      ctx.lineWidth = 2;
      ctx.fill();
      ctx.stroke();
      
      // Draw feed point
      ctx.beginPath();
      ctx.arc(centerX + 3, centerY + 3, 2.5, 0, Math.PI*2);
      ctx.fillStyle = 'var(--primary)';
      ctx.fill();
      
      activePlaygroundLoop = requestAnimationFrame(draw);
    }
    
    draw();
  }

  function loadRiscvPlayground(container) {
    container.innerHTML = `
      <div class="playground-header">
        <div class="playground-title"><i class="bx bx-chip"></i> RISC-V Logic Pipeline</div>
        <div class="riscv-ctrl-bar">
          <button class="inst-select-btn active" data-inst="add">ADD</button>
          <button class="inst-select-btn" data-inst="lw">LW</button>
          <button class="inst-select-btn" data-inst="beq">BEQ</button>
        </div>
      </div>
      <div class="riscv-playground">
        <canvas class="playground-canvas" id="riscv-canvas"></canvas>
        <div class="riscv-terminal" id="riscv-terminal-log">> System initialized. Select an instruction to simulate.</div>
      </div>
    `;

    const canvas = document.getElementById('riscv-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const logEl = document.getElementById('riscv-terminal-log');
    
    const btns = container.querySelectorAll('.inst-select-btn');
    let activeInst = 'add';
    
    const logsData = {
      add: [
        "FETCH:  Instruction loaded from 0x00400020 [0x00c58133]",
        "DECODE: add x2, x11, x12 | Source Registers: rs1=x11, rs2=x12",
        "EXECUTE: ALU ALU_OP=ADD | Input A = 0x00000045, Input B = 0x0000001E",
        "MEM_WB: ALU Out = 0x00000063 | RegWrite=1, MemToReg=0 | Reg[x2] <- 0x00000063"
      ],
      lw: [
        "FETCH:  Instruction loaded from 0x00400024 [0x0085a103]",
        "DECODE: lw x2, 8(x11) | Base Reg: rs1=x11 (0x1000b000), Offset=8",
        "EXECUTE: ALU ALU_OP=ADD (Addr calc) | 0x1000b000 + 8 = 0x1000b008",
        "MEM_WB: MemRead=1 | Loaded 0xdeadbeef from RAM[0x1000b008] -> Reg[x2] <- 0xdeadbeef"
      ],
      beq: [
        "FETCH:  Instruction loaded from 0x00400028 [0x00c58463]",
        "DECODE: beq x11, x12, offset+8 | Comparator: rs1=x11, rs2=x12",
        "EXECUTE: ALU ALU_OP=SUB (Compare) | 0x45 - 0x1E != 0 (Not Equal)",
        "MEM_WB: Branch=1, Zero=0 | Branch Not Taken. PC <- PC + 4 (0x0040002c)"
      ]
    };

    function updateLog(inst) {
      if (!logEl) return;
      const lines = logsData[inst];
      logEl.innerHTML = '';
      lines.forEach((line, index) => {
        setTimeout(() => {
          if (activePlaygroundId !== 'p1' || !logEl) return;
          const p = document.createElement('div');
          p.textContent = line;
          logEl.appendChild(p);
          logEl.scrollTop = logEl.scrollHeight;
        }, index * 400);
      });
    }

    btns.forEach(btn => {
      btn.addEventListener('click', () => {
        btns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeInst = btn.getAttribute('data-inst');
        updateLog(activeInst);
      });
    });

    updateLog(activeInst);

    let packetTimer = 0;
    const dataPackets = [];

    function draw() {
      if (activePlaygroundId !== 'p1') return;
      
      let w = canvas.width = canvas.parentElement.clientWidth;
      let h = canvas.height = canvas.parentElement.clientHeight - 70;

      ctx.clearRect(0, 0, w, h);
      
      const blockWidth = w * 0.12;
      const blockHeight = h * 0.18;
      const centerY = h * 0.5;
      
      const blocks = {
        pc: { x: w * 0.08, y: centerY, label: 'PC', desc: 'Program Counter' },
        im: { x: w * 0.25, y: centerY, label: 'I-MEM', desc: 'Inst Memory' },
        rf: { x: w * 0.44, y: centerY, label: 'REG-FILE', desc: 'Registers' },
        ctrl: { x: w * 0.44, y: centerY - h * 0.28, label: 'CONTROL', desc: 'Control Unit' },
        alu: { x: w * 0.65, y: centerY, label: 'ALU', desc: 'Arith Logic' },
        dm: { x: w * 0.85, y: centerY, label: 'D-MEM', desc: 'Data Memory' }
      };

      ctx.lineWidth = 1.5;
      ctx.shadowBlur = 0;

      for (let key in blocks) {
        const b = blocks[key];
        const isControl = key === 'ctrl';
        
        ctx.fillStyle = '#111116';
        ctx.strokeStyle = isControl ? 'rgba(0, 255, 255, 0.4)' : 'rgba(255, 255, 255, 0.15)';
        
        ctx.beginPath();
        if (key === 'alu') {
          const aluW = blockWidth * 1.1;
          const aluH = blockHeight * 1.3;
          ctx.moveTo(b.x - aluW/2, b.y - aluH/2);
          ctx.lineTo(b.x + aluW/2, b.y - aluH/4);
          ctx.lineTo(b.x + aluW/2, b.y + aluH/4);
          ctx.lineTo(b.x - aluW/2, b.y + aluH/2);
          ctx.lineTo(b.x - aluW/2, b.y + aluH/8);
          ctx.lineTo(b.x - aluW/2 + aluW*0.2, b.y);
          ctx.lineTo(b.x - aluW/2, b.y - aluH/8);
        } else {
          ctx.roundRect(b.x - blockWidth/2, b.y - blockHeight/2, blockWidth, blockHeight, 6);
        }
        ctx.fill();
        ctx.stroke();
        
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 11px Outfit';
        ctx.textAlign = 'center';
        ctx.fillText(b.label, b.x, b.y - 2);
        
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.font = '8px monospace';
        ctx.fillText(b.desc, b.x, b.y + 10);
      }

      const busColor = 'rgba(255, 255, 255, 0.05)';
      const activeColor = 'var(--primary)';
      const ctrlColor = 'rgba(0, 255, 255, 0.8)';
      
      const buses = [
        { points: [[blocks.pc.x + blockWidth/2, blocks.pc.y], [blocks.im.x - blockWidth/2, blocks.im.y]], active: ['add', 'lw', 'beq'] },
        { points: [[blocks.im.x + blockWidth/2, blocks.im.y], [blocks.rf.x - blockWidth/2, blocks.rf.y]], active: ['add', 'lw', 'beq'] },
        { points: [[blocks.im.x + blockWidth/4, blocks.im.y - blockHeight/2], [blocks.im.x + blockWidth/4, blocks.ctrl.y], [blocks.ctrl.x - blockWidth/2, blocks.ctrl.y]], active: ['add', 'lw', 'beq'] },
        { points: [[blocks.ctrl.x + blockWidth/4, blocks.ctrl.y + blockHeight/2], [blocks.ctrl.x + blockWidth/4, blocks.alu.y - blockHeight/2]], active: ['add', 'lw', 'beq'], type: 'ctrl' },
        { points: [[blocks.rf.x + blockWidth/2, blocks.rf.y - blockHeight/4], [blocks.alu.x - blockWidth*0.55, blocks.alu.y - blockHeight/3]], active: ['add', 'lw', 'beq'] },
        { points: [[blocks.rf.x + blockWidth/2, blocks.rf.y + blockHeight/4], [blocks.alu.x - blockWidth*0.55, blocks.alu.y + blockHeight/3]], active: ['add', 'beq'] },
        { points: [[blocks.rf.x + blockWidth/3, blocks.rf.y + blockHeight/2], [blocks.rf.x + blockWidth/3, blocks.rf.y + blockHeight*0.75], [blocks.dm.x - blockWidth/4, blocks.rf.y + blockHeight*0.75], [blocks.dm.x - blockWidth/4, blocks.dm.y + blockHeight/2]], active: [] },
        { points: [[blocks.alu.x + blockWidth*0.55, blocks.alu.y], [blocks.dm.x - blockWidth/2, blocks.dm.y]], active: ['lw'] },
        { points: [[blocks.alu.x + blockWidth*0.55, blocks.alu.y], [blocks.alu.x + blockWidth*0.8, blocks.alu.y], [blocks.alu.x + blockWidth*0.8, blocks.rf.y + blockHeight*0.9], [blocks.rf.x, blocks.rf.y + blockHeight*0.9], [blocks.rf.x, blocks.rf.y + blockHeight/2]], active: ['add'] },
        { points: [[blocks.dm.x + blockWidth/2, blocks.dm.y], [blocks.dm.x + blockWidth*0.7, blocks.dm.y], [blocks.dm.x + blockWidth*0.7, blocks.rf.y + blockHeight*1.0], [blocks.rf.x - blockWidth*0.1, blocks.rf.y + blockHeight*1.0], [blocks.rf.x - blockWidth*0.1, blocks.rf.y + blockHeight/2]], active: ['lw'] },
        { points: [[blocks.alu.x, blocks.alu.y - blockHeight*0.65], [blocks.alu.x, blocks.alu.y - blockHeight*0.95], [blocks.pc.x, blocks.alu.y - blockHeight*0.95], [blocks.pc.x, blocks.pc.y - blockHeight/2]], active: ['beq'], type: 'ctrl' }
      ];

      buses.forEach(bus => {
        const isActive = bus.active.includes(activeInst);
        ctx.beginPath();
        ctx.moveTo(bus.points[0][0], bus.points[0][1]);
        for (let i = 1; i < bus.points.length; i++) {
          ctx.lineTo(bus.points[i][0], bus.points[i][1]);
        }
        
        ctx.strokeStyle = isActive ? (bus.type === 'ctrl' ? ctrlColor : activeColor) : busColor;
        ctx.lineWidth = isActive ? 2.5 : 1.0;
        
        if (isActive) {
          ctx.shadowBlur = 6;
          ctx.shadowColor = bus.type === 'ctrl' ? ctrlColor : activeColor;
        } else {
          ctx.shadowBlur = 0;
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
      });

      packetTimer++;
      if (packetTimer % 20 === 0) {
        buses.forEach((bus, busIdx) => {
          if (bus.active.includes(activeInst)) {
            dataPackets.push({
              busIdx: busIdx,
              segmentIdx: 0,
              segmentProgress: 0,
              color: bus.type === 'ctrl' ? '#00ffff' : '#ff8c00',
              speed: 1.8
            });
          }
        });
      }

      ctx.fillStyle = '#ffffff';
      for (let i = dataPackets.length - 1; i >= 0; i--) {
        const p = dataPackets[i];
        const bus = buses[p.busIdx];
        
        if (!bus) {
          dataPackets.splice(i, 1);
          continue;
        }
        
        const ptStart = bus.points[p.segmentIdx];
        const ptEnd = bus.points[p.segmentIdx + 1];
        
        if (!ptEnd) {
          dataPackets.splice(i, 1);
          continue;
        }
        
        const dx = ptEnd[0] - ptStart[0];
        const dy = ptEnd[1] - ptStart[1];
        const segLen = Math.sqrt(dx*dx + dy*dy);
        
        p.segmentProgress += p.speed;
        
        if (p.segmentProgress >= segLen) {
          p.segmentProgress = 0;
          p.segmentIdx++;
          if (p.segmentIdx >= bus.points.length - 1) {
            dataPackets.splice(i, 1);
            continue;
          }
        }
        
        const ratio = segLen > 0 ? p.segmentProgress / segLen : 0;
        const curX = ptStart[0] + dx * ratio;
        const curY = ptStart[1] + dy * ratio;
        
        ctx.shadowBlur = 8;
        ctx.shadowColor = p.color;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(curX, curY, 3.5, 0, Math.PI*2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
      
      activePlaygroundLoop = requestAnimationFrame(draw);
    }

    draw();
  }

  function loadMecQuickPlayground(container) {
    container.innerHTML = `
      <div class="playground-header">
        <div class="playground-title"><i class="bx bxs-map"></i> MecQuick Optimization Engine</div>
        <div class="mecquick-ctrl-bar">
          <button class="optim-run-btn" id="optim-run-btn"><i class="bx bx-play-circle"></i> Dispatch Mechanic</button>
        </div>
      </div>
      <div class="mecquick-playground">
        <canvas class="playground-canvas" id="mecquick-canvas"></canvas>
        <div class="mecquick-hud">
          <div class="mecquick-hud-title">Engine Stats</div>
          <div>Breakdown: <span id="mq-hud-breakdown" style="color: #ff8c00;">Node 8</span></div>
          <div>Mechanic: <span id="mq-hud-mech" style="color: #00ffff;">Shop B</span></div>
          <div>Distance: <span id="mq-hud-dist" style="color: #2ecc71;">3.8 km</span></div>
          <div>ETA: <span id="mq-hud-eta" style="color: #2ecc71;">4.5 min</span></div>
        </div>
        <div class="mecquick-hint-overlay">Click any node on the map to set a new breakdown location</div>
      </div>
    `;

    const canvas = document.getElementById('mecquick-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    const hudBreakdown = document.getElementById('mq-hud-breakdown');
    const hudMech = document.getElementById('mq-hud-mech');
    const hudDist = document.getElementById('mq-hud-dist');
    const hudEta = document.getElementById('mq-hud-eta');
    const runBtn = document.getElementById('optim-run-btn');

    const nodes = [
      { id: 0, x: 0.15, y: 0.20, label: 'Node 0' },
      { id: 1, x: 0.12, y: 0.50, label: 'Shop A', type: 'shop', name: 'Shop A' },
      { id: 2, x: 0.20, y: 0.80, label: 'Node 2' },
      { id: 3, x: 0.40, y: 0.18, label: 'Node 3' },
      { id: 4, x: 0.38, y: 0.52, label: 'Node 4' },
      { id: 5, x: 0.42, y: 0.82, label: 'Node 5' },
      { id: 6, x: 0.65, y: 0.22, label: 'Shop B', type: 'shop', name: 'Shop B' },
      { id: 7, x: 0.62, y: 0.54, label: 'Node 7' },
      { id: 8, x: 0.68, y: 0.85, label: 'Breakdown', type: 'breakdown' },
      { id: 9, x: 0.88, y: 0.50, label: 'Shop C', type: 'shop', name: 'Shop C' }
    ];

    const edges = [
      [0, 1, 3.2], [0, 3, 2.5], [1, 2, 2.8], [1, 4, 3.0], [2, 5, 3.5],
      [3, 4, 2.1], [3, 6, 2.9], [4, 5, 2.4], [4, 7, 2.7], [5, 8, 3.1],
      [6, 7, 2.2], [6, 9, 3.8], [7, 8, 2.6], [7, 9, 2.5], [8, 9, 3.2]
    ];

    let breakdownNodeId = 8;
    let selectedMechanicNodeId = 6;
    let shortestPath = [];
    let pathCarProgress = -1;
    let scanningActive = false;
    let scanTimer = 0;
    
    function runDijkstra() {
      scanningActive = true;
      scanTimer = 0;
      pathCarProgress = -1;
      
      const start = breakdownNodeId;
      const dist = {};
      const prev = {};
      const q = new Set();
      
      nodes.forEach(n => {
        dist[n.id] = Infinity;
        prev[n.id] = null;
        q.add(n.id);
      });
      dist[start] = 0;
      
      while (q.size > 0) {
        let u = null;
        q.forEach(nid => {
          if (u === null || dist[nid] < dist[u]) {
            u = nid;
          }
        });
        
        if (dist[u] === Infinity) break;
        q.delete(u);
        
        edges.forEach(e => {
          let neighbor = null;
          let weight = 0;
          if (e[0] === u) { neighbor = e[1]; weight = e[2]; }
          else if (e[1] === u) { neighbor = e[0]; weight = e[2]; }
          
          if (neighbor !== null && q.has(neighbor)) {
            const alt = dist[u] + weight;
            if (alt < dist[neighbor]) {
              dist[neighbor] = alt;
              prev[neighbor] = u;
            }
          }
        });
      }
      
      const shopNodes = [1, 6, 9];
      let bestShopId = 6;
      let minDistance = Infinity;
      
      shopNodes.forEach(sid => {
        if (dist[sid] < minDistance) {
          minDistance = dist[sid];
          bestShopId = sid;
        }
      });
      
      selectedMechanicNodeId = bestShopId;
      
      const path = [];
      let curr = bestShopId;
      while (curr !== null) {
        path.push(curr);
        curr = prev[curr];
      }
      shortestPath = path;
      
      const shopNode = nodes.find(n => n.id === bestShopId);
      if (hudBreakdown) hudBreakdown.textContent = `Node ${breakdownNodeId}`;
      if (hudMech) hudMech.textContent = shopNode ? shopNode.name : 'Unknown';
      if (hudDist) hudDist.textContent = `${minDistance.toFixed(1)} km`;
      if (hudEta) hudEta.textContent = `${(minDistance * 1.2).toFixed(1)} mins`;
    }

    canvas.addEventListener('click', (e) => {
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;
      
      let w = canvas.width;
      let h = canvas.height;
      
      let closestNode = null;
      let minDist = 35;
      
      nodes.forEach(n => {
        if (n.type === 'shop') return;
        const nx = n.x * w;
        const ny = n.y * h;
        const d = Math.sqrt((clickX - nx)*(clickX - nx) + (clickY - ny)*(clickY - ny));
        if (d < minDist) {
          closestNode = n;
          minDist = d;
        }
      });
      
      if (closestNode !== null) {
        nodes.forEach(n => {
          if (n.type === 'breakdown') {
            n.type = undefined;
            n.label = `Node ${n.id}`;
          }
        });
        
        breakdownNodeId = closestNode.id;
        closestNode.type = 'breakdown';
        closestNode.label = 'Breakdown';
        
        runDijkstra();
      }
    });

    runBtn.addEventListener('click', () => {
      runDijkstra();
      setTimeout(() => {
        pathCarProgress = 0;
      }, 800);
    });

    runDijkstra();

    function draw() {
      if (activePlaygroundId !== 'p6') return;
      
      let w = canvas.width = canvas.parentElement.clientWidth;
      let h = canvas.height = canvas.parentElement.clientHeight - 45;

      ctx.clearRect(0, 0, w, h);
      
      ctx.lineWidth = 2.0;
      edges.forEach(e => {
        const from = nodes.find(n => n.id === e[0]);
        const to = nodes.find(n => n.id === e[1]);
        if (!from || !to) return;
        
        let isPathEdge = false;
        if (!scanningActive && pathCarProgress >= 0 && shortestPath.length > 1) {
          for (let i = 0; i < shortestPath.length - 1; i++) {
            if ((shortestPath[i] === from.id && shortestPath[i+1] === to.id) ||
                (shortestPath[i] === to.id && shortestPath[i+1] === from.id)) {
              isPathEdge = true;
            }
          }
        }
        
        ctx.beginPath();
        ctx.moveTo(from.x * w, from.y * h);
        ctx.lineTo(to.x * w, to.y * h);
        ctx.strokeStyle = isPathEdge ? 'var(--primary)' : 'rgba(255, 255, 255, 0.05)';
        if (isPathEdge) {
          ctx.shadowBlur = 8;
          ctx.shadowColor = 'var(--primary)';
        } else {
          ctx.shadowBlur = 0;
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
        
        const midX = ((from.x + to.x) / 2) * w;
        const midY = ((from.y + to.y) / 2) * h - 5;
        ctx.fillStyle = 'rgba(255,255,255,0.15)';
        ctx.font = '8px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(e[2] + 'k', midX, midY);
      });
      
      if (scanningActive) {
        scanTimer += 1.5;
        if (scanTimer < 45) {
          const bdNode = nodes.find(n => n.id === breakdownNodeId);
          if (bdNode) {
            ctx.beginPath();
            ctx.arc(bdNode.x * w, bdNode.y * h, scanTimer * 5, 0, Math.PI*2);
            ctx.strokeStyle = 'rgba(0, 255, 255, ' + (1.0 - scanTimer/45) + ')';
            ctx.lineWidth = 2;
            ctx.stroke();
          }
        } else {
          scanningActive = false;
        }
      }

      nodes.forEach(n => {
        const nx = n.x * w;
        const ny = n.y * h;
        
        let strokeColor = 'rgba(255, 255, 255, 0.15)';
        let fillColor = '#111116';
        let r = 8;
        
        if (n.type === 'shop') {
          strokeColor = '#00ffff';
          fillColor = n.id === selectedMechanicNodeId && !scanningActive ? 'rgba(0, 255, 255, 0.15)' : '#111116';
          r = 10;
        } else if (n.type === 'breakdown') {
          strokeColor = '#ff8c00';
          fillColor = 'rgba(253, 111, 0, 0.2)';
          r = 10;
        }
        
        ctx.beginPath();
        ctx.arc(nx, ny, r, 0, Math.PI*2);
        ctx.fillStyle = fillColor;
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = 2;
        
        if (n.type === 'breakdown' || (n.id === selectedMechanicNodeId && !scanningActive)) {
          ctx.shadowBlur = 10;
          ctx.shadowColor = strokeColor;
        }
        
        ctx.fill();
        ctx.stroke();
        ctx.shadowBlur = 0;
        
        ctx.fillStyle = n.type ? '#fff' : 'rgba(255, 255, 255, 0.4)';
        ctx.font = 'bold 8px Outfit';
        ctx.textAlign = 'center';
        ctx.fillText(n.label, nx, ny - r - 4);
      });

      if (!scanningActive && pathCarProgress >= 0 && shortestPath.length > 1) {
        pathCarProgress += 0.012;
        if (pathCarProgress >= shortestPath.length - 1) {
          pathCarProgress = -1;
        } else {
          const segIdx = Math.floor(pathCarProgress);
          const ratio = pathCarProgress - segIdx;
          
          const fromNode = nodes.find(n => n.id === shortestPath[segIdx]);
          const toNode = nodes.find(n => n.id === shortestPath[segIdx + 1]);
          
          if (fromNode && toNode) {
            const carX = (fromNode.x + (toNode.x - fromNode.x) * ratio) * w;
            const carY = (fromNode.y + (toNode.y - fromNode.y) * ratio) * h;
            
            ctx.shadowBlur = 12;
            ctx.shadowColor = '#00ff00';
            ctx.fillStyle = '#00ff00';
            ctx.beginPath();
            
            const angle = Math.atan2(toNode.y - fromNode.y, toNode.x - fromNode.x);
            ctx.translate(carX, carY);
            ctx.rotate(angle);
            ctx.moveTo(8, 0);
            ctx.lineTo(-6, -5);
            ctx.lineTo(-6, 5);
            ctx.closePath();
            ctx.fill();
            
            ctx.rotate(-angle);
            ctx.translate(-carX, -carY);
            ctx.shadowBlur = 0;
          }
        }
      }
      
      activePlaygroundLoop = requestAnimationFrame(draw);
    }

    draw();
  }

});
