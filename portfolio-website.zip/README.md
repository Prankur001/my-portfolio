# Premium Personal Portfolio & Admin Console Website

A responsive, high-end personal portfolio website styled exactly as requested, built with a robust Node.js and Express.js backend. It features a working contact form that records submissions to a database and an interactive **Admin Console** where you can review, filter, mark as read/unread, or delete submissions.

## Design Highlights
- **Stunning Dark Aesthetic**: Elegant charcoal layout matching the mockup design with a warm orange primary accent (`#fd6f00`).
- **Interactive Animations**: Micro-animations on buttons and links, stats count-up animation, progressive skills progress bar transitions.
- **Dynamic Portfolio Grid**: Fully interactive project cards featuring modal popups showing complete case metadata.
- **Responsive Navigation**: Full mobile compatibility with touch-responsive sliding navigation drawer.

---

## Folder Structure
```text
portfolio-website/
├── public/                # Frontend Source Code
│   ├── css/
│   │   └── styles.css     # Unified UI/UX & Responsive Styles
│   ├── js/
│   │   ├── main.js        # Landing page interactive dynamics & Forms API
│   │   └── admin.js       # Admin panel auth states & list renderer
│   ├── images/
│   │   └── avatar.png     # Generated high-quality profile headshot
│   ├── index.html         # Main portfolio landing page
│   └── admin.html         # Admin logs manager portal
├── data/
│   └── inquiries.json     # Saved messages database logs (Auto-created)
├── .env                   # Environment config (Port, credentials)
├── server.js              # Node.js + Express backend router controller
├── package.json           # Scripts and dependencies configurations
└── zip-project.js         # Packaging utility script
```

---

## Quick Start Guide

### 1. Prerequisites
Ensure you have [Node.js](https://nodejs.org/) installed (v16.0.0 or higher is recommended).

### 2. Installation
Extract the ZIP archive, open your command terminal in the extracted folder (`portfolio-website`), and run:
```bash
npm install
```

### 3. Environment Variables
A default `.env` file is provided:
- `PORT=3000` (The port the server runs on)
- `ADMIN_PASSWORD=admin1234` (Password to access `/admin.html` dashboard)
- `SESSION_SECRET=portfolio-super-secret-key-98765` (JWT token secret)

Feel free to customize the `ADMIN_PASSWORD` in your `.env` file!

### 4. Running the Website
Start the local server using:
```bash
npm start
```

Once started, open your web browser and navigate to:
- **Landing Portfolio**: [http://localhost:3000](http://localhost:3000)
- **Admin Dashboard Console**: [http://localhost:3000/admin.html](http://localhost:3000/admin.html)

---

## Using the Website

1. **Submit Inquiries**: Open the main website, navigate to the **Let's Design Together** section at the bottom, fill out the form and submit.
2. **Review Messages**: Go to `/admin.html`, enter your password (default: `admin1234`), and unlock the console. You will see count widgets representing total messages, unread, and read statuses, along with an interactive list of all submitted forms.
3. **Admin Controls**:
   - **Reply**: Opens a standard mail client template targeting the sender's email.
   - **Mark Read/Unread**: Updates status badges dynamically in the database without page reload.
   - **Delete**: Cleans up spam or processed items.
