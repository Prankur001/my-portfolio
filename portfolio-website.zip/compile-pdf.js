const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const htmlPath = path.join(__dirname, 'public', 'resume.html');
const pdfPath = path.join(__dirname, 'public', 'resume.pdf');

// Common installation paths for Chrome on Windows
const userProfile = process.env.USERPROFILE || '';
const chromePaths = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  path.join(userProfile, 'AppData', 'Local', 'Google', 'Chrome', 'Application', 'chrome.exe')
];

let chromeExecutable = null;
for (const p of chromePaths) {
  if (fs.existsSync(p)) {
    chromeExecutable = p;
    break;
  }
}

if (!chromeExecutable) {
  console.error('Error: Google Chrome executable could not be located in standard paths.');
  process.exit(1);
}

console.log(`Found Google Chrome at: ${chromeExecutable}`);
console.log(`Compiling HTML resume: ${htmlPath} to PDF...`);

// Run Chrome in headless mode to print the webpage to PDF
const args = [
  '--headless',
  '--disable-gpu',
  `--print-to-pdf=${pdfPath}`,
  '--no-pdf-header-footer', // Avoid printing date, URL, page title headers
  htmlPath
];

const result = spawnSync(chromeExecutable, args);

if (result.error) {
  console.error('Error executing Chrome process:', result.error.message);
  process.exit(1);
}

if (fs.existsSync(pdfPath)) {
  const stats = fs.statSync(pdfPath);
  console.log('==================================================');
  console.log('PDF RESUME CREATED SUCCESSFULLY!');
  console.log(`PDF File: ${pdfPath}`);
  console.log(`Size: ${(stats.size / 1024).toFixed(2)} KB`);
  console.log('==================================================');
} else {
  console.error('Error: Chrome process completed but PDF file was not created.');
  process.exit(1);
}
