document.addEventListener('DOMContentLoaded', () => {
  const loginOverlay = document.getElementById('login-overlay');
  const adminMainPanel = document.getElementById('admin-main-panel');
  const loginForm = document.getElementById('login-form');
  const loginPassInput = document.getElementById('login-pass');
  const loginError = document.getElementById('login-error');
  
  const logoutBtn = document.getElementById('logout-btn');
  const refreshInboxBtn = document.getElementById('refresh-inbox-btn');
  
  const messagesList = document.getElementById('messages-list');
  const emptyState = document.getElementById('empty-state');
  
  // Dashboard Stats
  const statTotal = document.getElementById('stat-total');
  const statUnread = document.getElementById('stat-unread');
  const statRead = document.getElementById('stat-read');

  // Check login session storage token
  let token = sessionStorage.getItem('admin_token');
  if (token) {
    showDashboard();
  } else {
    showLogin();
  }

  // --- Navigation States Toggle ---
  function showDashboard() {
    loginOverlay.classList.add('hidden');
    adminMainPanel.classList.remove('hidden');
    fetchInquiries();
  }

  function showLogin() {
    loginOverlay.classList.remove('hidden');
    adminMainPanel.classList.add('hidden');
    loginPassInput.value = '';
    loginPassInput.focus();
  }

  // --- Auth Handlers ---
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const password = loginPassInput.value;
      loginError.classList.add('hidden');

      try {
        const response = await fetch('/api/admin/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ password })
        });

        const data = await response.json();

        if (response.ok && data.success) {
          token = data.token;
          sessionStorage.setItem('admin_token', token);
          showDashboard();
        } else {
          loginError.textContent = data.error || 'Authentication failed.';
          loginError.classList.remove('hidden');
        }
      } catch (err) {
        console.error('Login request error:', err);
        loginError.textContent = 'Server unreachable. Verify backend is running.';
        loginError.classList.remove('hidden');
      }
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      sessionStorage.removeItem('admin_token');
      token = null;
      showLogin();
    });
  }

  if (refreshInboxBtn) {
    refreshInboxBtn.addEventListener('click', () => {
      fetchInquiries();
    });
  }

  // --- Fetch Inquiries Database logs ---
  async function fetchInquiries() {
    if (!token) return;

    try {
      const response = await fetch('/api/admin/inquiries', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.status === 401 || response.status === 403) {
        // Session expired or invalid
        sessionStorage.removeItem('admin_token');
        token = null;
        showLogin();
        return;
      }

      const inquiries = await response.json();
      renderDashboard(inquiries);
    } catch (err) {
      console.error('Fetch inquiries error:', err);
      alert('Failed to connect to backend server. Try refreshing.');
    }
  }

  // --- Render Dashboard UI ---
  function renderDashboard(inquiries) {
    // 1. Set Counter Stats
    const total = inquiries.length;
    const unread = inquiries.filter(item => item.status === 'unread').length;
    const read = total - unread;

    statTotal.textContent = total;
    statUnread.textContent = unread;
    statRead.textContent = read;

    // 2. Clear Messages container
    messagesList.innerHTML = '';

    if (total === 0) {
      emptyState.classList.remove('hidden');
      messagesList.classList.add('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    messagesList.classList.remove('hidden');

    // 3. Hydrate message list cards
    inquiries.forEach(item => {
      const messageCard = document.createElement('div');
      messageCard.className = `message-item ${item.status === 'unread' ? 'unread-message' : ''}`;
      
      const dateFormatted = new Date(item.date).toLocaleString(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short'
      });

      messageCard.innerHTML = `
        <div class="message-item-header">
          <div class="message-sender">
            <span class="sender-name">${escapeHtml(item.name)}</span>
            <a href="mailto:${escapeHtml(item.email)}" class="sender-email">${escapeHtml(item.email)}</a>
          </div>
          <span class="message-date">${dateFormatted}</span>
        </div>
        <div class="message-subject">Subject: ${escapeHtml(item.subject)}</div>
        <div class="message-body">${escapeHtml(item.message)}</div>
        <div class="message-item-actions">
          <a href="mailto:${escapeHtml(item.email)}?subject=RE: ${encodeURIComponent(item.subject)}" class="btn btn-outline btn-sm btn-action" style="padding:0.4rem 0.75rem;"><i class="bx bx-reply"></i> Reply</a>
          <button class="btn btn-outline btn-sm btn-action toggle-status-btn" data-id="${item.id}" data-status="${item.status}">
            <i class="bx ${item.status === 'unread' ? 'bx-check-double' : 'bx-envelope'}"></i> 
            ${item.status === 'unread' ? 'Mark Read' : 'Mark Unread'}
          </button>
          <button class="btn btn-primary btn-sm btn-action delete-message-btn" data-id="${item.id}" style="background-color:#e74c3c;">
            <i class="bx bx-trash"></i> Delete
          </button>
        </div>
      `;

      messagesList.appendChild(messageCard);
    });

    // 4. Attach action button listeners
    document.querySelectorAll('.toggle-status-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        const currentStatus = e.currentTarget.getAttribute('data-status');
        const targetStatus = currentStatus === 'unread' ? 'read' : 'unread';
        
        await updateInquiryStatus(id, targetStatus);
      });
    });

    document.querySelectorAll('.delete-message-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        if (confirm('Are you sure you want to permanently delete this message?')) {
          await deleteInquiry(id);
        }
      });
    });
  }

  // --- API Action Calls ---
  async function updateInquiryStatus(id, targetStatus) {
    try {
      const response = await fetch(`/api/admin/inquiries/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status: targetStatus })
      });

      if (response.ok) {
        fetchInquiries(); // Reload dashboard lists
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to update message status.');
      }
    } catch (err) {
      console.error('Update status error:', err);
      alert('Network error. Check backend server.');
    }
  }

  async function deleteInquiry(id) {
    try {
      const response = await fetch(`/api/admin/inquiries/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        fetchInquiries(); // Reload dashboard lists
      } else {
        const data = await response.json();
        alert(data.error || 'Failed to delete message.');
      }
    } catch (err) {
      console.error('Delete message error:', err);
      alert('Network error. Check backend server.');
    }
  }

  // Simple HTML Escaping to prevent XSS injection in dashboard display
  function escapeHtml(string) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return string.replace(/[&<>"']/g, function(m) { return map[m]; });
  }

});
